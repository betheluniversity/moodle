This plugin was contributed by the Moodlerooms Product Development team.  Moodlerooms is an education technology company
dedicated to bringing excellent online teaching to institutions across the globe.  We serve colleges and universities,
schools and organizations by supporting the software that educators use to manage and deliver instructional content to
learners in virtual classrooms.  Moodlerooms is headquartered in Baltimore, MD.  We are proud to be a Moodle Partner company.

For more information about installation, configuration and usage, please contact your Ellucian representative.